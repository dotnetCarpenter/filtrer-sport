This began as a gist: https://gist.github.com/dotnetCarpenter/855c165ff4a7d69d5458b2ce477da59d

